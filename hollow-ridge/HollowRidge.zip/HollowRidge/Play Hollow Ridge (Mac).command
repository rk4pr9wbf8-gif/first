#!/bin/bash
# Opens Hollow Ridge in its own fullscreen window using Chrome, Edge, Brave or Chromium.
DIR="$(cd "$(dirname "$0")" && pwd)"
URL="file://$DIR/index.html"
for APP in "Google Chrome" "Microsoft Edge" "Brave Browser" "Chromium"; do
  if [ -d "/Applications/$APP.app" ]; then
    open -na "$APP" --args --app="$URL" --start-fullscreen --force_high_performance_gpu --ignore-gpu-blocklist --user-data-dir="$HOME/Library/Application Support/HollowRidge"
    exit 0
  fi
done
open "$DIR/index.html"
