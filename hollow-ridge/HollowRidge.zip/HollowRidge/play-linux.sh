#!/bin/sh
# Opens Hollow Ridge in its own fullscreen window using Chrome or Chromium.
DIR="$(cd "$(dirname "$0")" && pwd)"
for B in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge brave-browser; do
  if command -v "$B" >/dev/null 2>&1; then
    exec "$B" --app="file://$DIR/index.html" --start-fullscreen --ignore-gpu-blocklist --user-data-dir="$HOME/.config/hollow-ridge"
  fi
done
xdg-open "$DIR/index.html"
