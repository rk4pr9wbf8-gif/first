@echo off
rem Opens Hollow Ridge in its own fullscreen window using Chrome or Edge,
rem asking for the faster graphics card on laptops that have two.
setlocal
set "HERE=%~dp0"
set "PAGE=file:///%HERE:\=/%index.html"
set "B="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "B=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined B if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "B=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined B if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "B=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined B if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "B=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined B if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "B=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined B ( start "" "%HERE%index.html" & exit /b )
start "" "%B%" --app="%PAGE%" --start-fullscreen --force_high_performance_gpu --ignore-gpu-blocklist --user-data-dir="%LocalAppData%\HollowRidge"
