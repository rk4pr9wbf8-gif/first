HOLLOW RIDGE
Late October in the Blue Ridge. Wander, visit the farm, follow the creek, build a cabin.

HOW TO PLAY
  Windows: double-click "Play Hollow Ridge (Windows).bat"
  Mac:     double-click "Play Hollow Ridge (Mac).command"
           (the first time, macOS may say it is from an unidentified developer:
            right-click the file, choose Open, then Open again)
  Linux:   run ./play-linux.sh
  Or just open index.html in Chrome, Edge, Brave or Firefox.

The launchers open the game in its own fullscreen window and ask your computer
for its faster graphics card (on laptops that have two), which helps it run smoothly.
Everything runs offline. Your builds are saved on this computer.

CONTROLS
  WASD + mouse ......... walk and look (Shift = faster)
  Space / F ............ jump / toggle flying (Space and C to rise and sink)
  Left click an animal . pet it (the farm dog will start following you)
  Right / Left click ... place a building piece / take it back
  1-0, mouse wheel ..... choose a piece      R ... rotate it
  Q / E ................ move time backward / forward    T ... hold time still
  V .................... dream level (gentle color flow, trails, aurora)
  B .................... building on/off     H ... hide HUD
  M .................... music on/off        G ... cycle graphics (Low / High / Ultra)
  Esc .................. pause menu (dream, time, volume, graphics)

If it feels slow, pick "Low" graphics in the pause menu. "Auto" (the default) steps
down by itself if the first few seconds run slowly.
